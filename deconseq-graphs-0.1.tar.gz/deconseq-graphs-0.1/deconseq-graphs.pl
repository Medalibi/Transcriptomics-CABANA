#!/usr/bin/perl

use strict;
use warnings;

use Cairo;
#use Font::FreeType;
#use Data::Dumper; ###

$| = 1; #don't buffer output

my $IDENTITY_MIN = 60;
my $PI = 4 * atan2(1, 1);

die "Usage:\nperl deconseq-graphs.pl <tsv_file> <output_prefix> <dbs> <dbs_retain>\n\nExample:\nperl deconseq-graphs.pl example.tsv example_out \"hsref,hs1,hsunique\" \"vir,bact\"\nperl deconseq-graphs.pl example.tsv example_out \"hsref,hs1,hsunique\"\n" if (@ARGV < 3);

#tsv file, prefix, dbs, dbs_retain
&runStuff(@ARGV[0..3]);

################################################################################

sub runStuff {
	my ($tsvfile,$out_prefix,$dbs_input,$dbs_retain_input) = @_;
    die "ERROR: No tsv file given." unless(defined $tsvfile);
    die "ERROR: No output file prefix given." unless(defined $out_prefix);
    die "ERROR: No dbs value given." unless(defined $dbs_input);    

    if(-e $tsvfile) {
	    my %dbs = map { $_ => 1 } split(/\,/,$dbs_input);
        my $dbs_retain = $dbs_retain_input;
        #parse tsv file
        print STDERR "Parse tsv file\n";
        my (%cidata_rounded,@args,%cidata,$is_keep_db,$coverage,$identity);
        open(FILE,"<$tsvfile") or die "ERROR: could not open file $tsvfile: $! \n";
        while(<FILE>) {
            next if(/^\#/);
            chomp();
            @args = split(/\t/);
            #db name, query id, db id, db start, db align-length, coverage, identity
            $is_keep_db = (exists $dbs{$args[0]} ? 0 : 1);
            $coverage = int($args[5]);
            $identity = int($args[6]);
            next if(exists $cidata{$args[1]}->{$is_keep_db}->{$coverage} && $cidata{$args[1]}->{$is_keep_db}->{$coverage} >= $identity);
            $cidata{$args[1]}->{$is_keep_db}->{$coverage} = $identity;
        }
        close(FILE);

        print STDERR "Generate Coverage-Identity plots\n";
        #generate plot data
        print STDERR "Generate plots\n";
        my (%plotmatrix,$max);
        foreach my $qid (keys %cidata) {
            if(exists $cidata{$qid}->{0} && !exists $cidata{$qid}->{1}) {
                while(my ($c, $i) = each(%{$cidata{$qid}->{0}})) {
                    $plotmatrix{0}->{$c}->{$i}++;
                }
            }
        }
        $max = 0;
        foreach my $c (keys %{$plotmatrix{0}}) {
            foreach my $i (keys %{$plotmatrix{0}->{$c}}) {
                $max = $plotmatrix{0}->{$c}->{$i} if($plotmatrix{0}->{$c}->{$i} > $max);
            }
        }

        my $ci_plot = $out_prefix."_ci1.png";
        &generateCIPlot(\%plotmatrix,$max,$ci_plot);

        if($dbs_retain) {
            #generate plot data
            my (%plotmatrix,$max0,$max1,@connections,@tmp);
            foreach my $qid (keys %cidata) {
                if(exists $cidata{$qid}->{0} && exists $cidata{$qid}->{1}) {
                    @tmp = ();
                    while(my ($c, $i) = each(%{$cidata{$qid}->{0}})) {
                        $plotmatrix{0}->{$c}->{$i}++;
                        push(@tmp,[$c,$i]);
                    }
                    while(my ($c, $i) = each(%{$cidata{$qid}->{1}})) {
                        $plotmatrix{1}->{$c}->{$i}++;
                        foreach my $t (@tmp) {
                            push(@connections,[@$t,$c,$i]);
                        }

                    }
                }
            }
            $max0 = $max1 = 0;
            foreach my $c (keys %{$plotmatrix{0}}) {
                foreach my $i (keys %{$plotmatrix{0}->{$c}}) {
                    $max0 = $plotmatrix{0}->{$c}->{$i} if($plotmatrix{0}->{$c}->{$i} > $max0);
                }
            }
            foreach my $c (keys %{$plotmatrix{1}}) {
                foreach my $i (keys %{$plotmatrix{1}->{$c}}) {
                    $max1 = $plotmatrix{1}->{$c}->{$i} if($plotmatrix{1}->{$c}->{$i} > $max1);
                }
            }

            $ci_plot = $out_prefix."_ci2.png";
            &generateCIPlot(\%plotmatrix,($max0 > $max1 ? $max0 : $max1),$ci_plot,\@connections);
        }
        print STDERR "Done\n";
    }
}


sub generateCIPlot {
    my ($data,$max,$file,$connections) = @_;

    my $subvals = &calcSubVals($max);
    my @dotcol = (0, 0, 0, 0.8);
    my @col0 = (221/255, 85/255, 17/255);
    my @col1 = (102/255, 140/255, 217/255);
    my @dotcol0 = (@col0, 0.8);
    my @dotcol1 = (@col1, 0.8);
    my @linecol = (0, 0, 0, 0.4);
    my @linecol0 = (@col0, 0.05);
    my @linecol1 = (@col1, 0.05);
    my @barcol0 = (@col0, 0.8);
    my @barcol1 = (@col1, 0.8);
    my @helplinecol1 = (1,1,1, 0.9);
    my @helplinecol2 = (1,1,1, 0.5);

    #create new image
    my $size   = 5;
    my $offset = 20;
    my $left   = 38;
    my $top    = 90;
    my $right  = $top-$left;
    my $surface = Cairo::ImageSurface->create('argb32', 101*$size+$offset*2+15+$left+$right+15,101*$size+$offset*3+10+$top); #format, width, height
    my $cr = Cairo::Context->create($surface);

    my ($font_extents,$extents,$fontheight,$fontdescent);

    #background
#    $cr->rectangle(0, 0, 101*$size+$offset*2+15+$left+$right+15,101*$size+$offset*3+10+$top);
#    $cr->set_source_rgba(1, 1, 1, 1);
#    $cr->fill;

    #fonts
    $cr->select_font_face ('sans', 'normal', 'normal');
#    $cr->set_font_size (30);

    $cr->save;

    #set up work space
    $cr->translate($left+$offset, $top+$offset); #new 0,0
    my $plotwidth = 100*$size;
    my $plotheight = 100*$size;
    $cr->scale($plotwidth, $plotheight); #size of area for x=0.0-1.0,y=0.0-1.0

    my ($dx, $dy);


    $cr->set_antialias('none');
    ($dx, $dy) = (1, 1);
    ($dx, $dy) = $cr->device_to_user_distance($dx, $dy);
    if($dx < $dy) {
        $dx = $dy;
    }
    $cr->set_line_width($dx);

    #background for plot
    $cr->rectangle(0, 0-$dx, 1+$dx, 1+$dx);
    $cr->set_source_rgba(0.9, 0.9, 0.9, 1);
    $cr->fill;

    #draw plot help lines
    $cr->set_source_rgba(@helplinecol1);
    foreach my $i (2,4,6,8) {
        $cr->move_to(1/10*$i,0-$dx);
        $cr->line_to(1/10*$i,1+$dx);
#        $cr->move_to(1/10*$i,0);
#        $cr->line_to(1/10*$i,1);
    }
    $cr->stroke;
    foreach my $i (2,4,6,8) {
        $cr->move_to(0,1/10*$i);
        $cr->line_to(1+$dx,1/10*$i);
#        $cr->move_to(0,1/10*$i);
#        $cr->line_to(1,1/10*$i);
    }
    $cr->stroke;
    $cr->set_source_rgba(@helplinecol2);
    foreach my $i (1,3,5,7,9) {
        $cr->move_to(1/10*$i,0-$dx);
        $cr->line_to(1/10*$i,1+$dx);
    }
    $cr->stroke;
    foreach my $i (1,3,5,7,9) {
        $cr->move_to(0,1/10*$i);
        $cr->line_to(1+$dx,1/10*$i);
    }
    $cr->stroke;

    #draw ticks
    $cr->set_source_rgba(0, 0, 0, 0.8);
    ($dx, $dy) = (1, 1);
    ($dx, $dy) = $cr->device_to_user_distance($dx, $dy);
    if($dx < $dy) {
        $dx = $dy;
    }
    $cr->set_line_width($dx);
    foreach my $i (2,4,6,8) {
        $cr->move_to(1/10*$i, 1);
        $cr->line_to(1/10*$i, 1.01);
    }
    $cr->stroke;
    foreach my $i (2,4,6,8) {
        $cr->move_to(0, 1/10*$i);
        $cr->line_to(-0.01, 1/10*$i);
    }
    $cr->stroke;

    $cr->set_antialias('default');

    #tick labels
    $cr->set_font_size ($dx*10);
    $font_extents = $cr->font_extents;
    $fontheight = $font_extents->{height};
    foreach my $i (2,4,6,8) {
        $extents = $cr->text_extents($i*10);
        $cr->move_to(1/10*$i-$extents->{width}/2-$dx*2, 1.01+$fontheight);
        $cr->show_text($i*10);
    }
    $cr->stroke;
    foreach my $i (2,4,6,8) {
        $extents = $cr->text_extents((10-$i)*10);
        $cr->move_to(-0.01-$extents->{width}-$fontheight/2, 1/10*$i+$fontheight/2-$dx*2);
        $cr->show_text((10-$i)*10);
    }

    $cr->save;

    #axis labels
    $cr->set_source_rgba(0, 0, 0, 1);
    $cr->set_font_size ($dx*14);
    $font_extents = $cr->font_extents;
    $fontheight = $font_extents->{height};
    $extents = $cr->text_extents('Query Coverage in %');
    $cr->move_to(0.5-$extents->{width}/2, 1+$fontheight*2.5);
    $cr->show_text('Query Coverage in %');
    $cr->rotate($PI * 3 / 2);
    $extents = $cr->text_extents('Alignment Identity in %');
    $cr->move_to(-0.5-$extents->{width}/2, 0-$fontheight*2.5);
    $cr->show_text('Alignment Identity in %');

    $cr->restore;

    #draw connections
    foreach my $con (@$connections) {
        if($con->[0]+$con->[1] > $con->[2]+$con->[3]) {
            $cr->set_source_rgba(@linecol0);
        } else {
            $cr->set_source_rgba(@linecol1);
        }
        $cr->move_to($con->[0]/100,1-$con->[1]/100);
        $cr->line_to($con->[2]/100,1-$con->[3]/100);
        $cr->stroke;
    }

    #draw dots
    ($dx, $dy) = (1, 1);
    ($dx, $dy) = $cr->device_to_user_distance($dx, $dy);
    if($dx < $dy) {
        $dx = $dy;
    }
    foreach my $keep (keys %$data) {
        $cr->set_source_rgba(($keep ? @dotcol1 : @dotcol0));
        foreach my $c (keys %{$data->{$keep}}) {
            foreach my $i (keys %{$data->{$keep}->{$c}}) {
                $cr->arc($c/100, 1-$i/100, &getSubVal($subvals,$data->{$keep}->{$c}->{$i})*$dx, 0, 2*$PI);
                $cr->fill;
            }
        }
    }

    $cr->restore;

    #calculate values
    my (@sums,@sumsI); #I for Identity
    my (%sums,%maxsums,$sum);
    $maxsums{c} = 1;
    $maxsums{i} = 1;
    foreach my $keep (keys %$data) {
        foreach my $c (keys %{$data->{$keep}}) {
            foreach my $i (keys %{$data->{$keep}->{$c}}) {
                $sums{c}->{$c}->{$keep} += $data->{$keep}->{$c}->{$i};
                $sums{i}->{$i}->{$keep} += $data->{$keep}->{$c}->{$i};
            }
        }
    }
    foreach my $type (keys %sums) {
        foreach my $pos (keys %{$sums{$type}}) {
            $sum = 0;
            foreach my $keep (keys %{$sums{$type}->{$pos}}) {
                $sum += $sums{$type}->{$pos}->{$keep};
            }
            $maxsums{$type} = $sum if($maxsums{$type} < $sum);
        }
    }

    #draw site plots
    $cr->save;

    #coverage sums
    $cr->translate($left+$offset, $offset+8); #new 0,0
    $plotwidth = 100*$size;
    $plotheight = $top-15;
    $cr->scale($plotwidth, $plotheight); #size of area for x=0.0-1.0,y=0.0-1.0

    $cr->set_antialias('none');

    $cr->rectangle(0, 0, 1, 1);
    $cr->set_source_rgba(0.95, 0.95, 0.95, 1);
    $cr->fill;

    ($dx, $dy) = (1, 1);
    ($dx, $dy) = $cr->device_to_user_distance($dx, $dy);
    if($dx > $dy) {
        $dx = $dy;
    }
    $cr->set_line_width($dx);
    $cr->set_source_rgba(@helplinecol1);
    foreach my $i (2,4,6,8) {
        $cr->move_to(1/10*$i,0);
        $cr->line_to(1/10*$i,1);
    }
    $cr->stroke;
    $cr->set_source_rgba(@helplinecol2);
    foreach my $i (1,3,5,7,9) {
        $cr->move_to(1/10*$i,0);
        $cr->line_to(1/10*$i,1);
    }
    $cr->stroke;
    $cr->set_line_width($dy);
    $cr->set_source_rgba(@helplinecol1);
    foreach my $i (2.5,7.5) {
        $cr->move_to(0, 1/10*$i);
        $cr->line_to(1, 1/10*$i);
    }
    $cr->stroke;

    #draw ticks
    $cr->set_line_width($dy);
    $cr->set_source_rgba(0, 0, 0, 0.8);
    foreach my $i (2.5,7.5) {
        $cr->move_to(0, 1/10*$i);
        $cr->line_to(-0.01, 1/10*$i);
    }
    $cr->stroke;

    $cr->set_antialias('default');

    foreach my $pos (1..100) {
        next unless(exists $sums{c}->{$pos});
        my $tmp0 = (exists $sums{c}->{$pos}->{0} ? $sums{c}->{$pos}->{0} : 0) / $maxsums{c};
        my $tmp1 = (exists $sums{c}->{$pos}->{1} ? $sums{c}->{$pos}->{1} : 0) / $maxsums{c};
        if($tmp0) {
            $cr->set_source_rgba(@barcol0);
            $cr->rectangle($pos/100-0.004, 1, 0.008, -$tmp0);
            $cr->fill;
        }
        if($tmp1) {
            $cr->set_source_rgba(@barcol1);
            $cr->rectangle($pos/100-0.004, 1-$tmp0-($tmp0 ? 0.003 : 0), 0.008, -$tmp1+($tmp0 ? 0.003 : 0));
            $cr->fill;
        }
    }

    $cr->restore;

    $cr->save;

    #identity sums
    $cr->translate($left+$offset+101*$size+2, $offset+$top); #new 0,0
    $plotwidth = $top-15;
    $plotheight = 100*$size;
    $cr->scale($plotwidth, $plotheight); #size of area for x=0.0-1.0,y=0.0-1.0

    $cr->set_antialias('none');

    $cr->rectangle(0, 0, 1, 1);
    $cr->set_source_rgba(0.95, 0.95, 0.95, 1);
    $cr->fill;

    ($dx, $dy) = (1, 1);
    ($dx, $dy) = $cr->device_to_user_distance($dx, $dy);
    if($dx > $dy) {
        $dx = $dy;
    }
    $cr->set_line_width($dx);
    $cr->set_source_rgba(@helplinecol1);
    foreach my $i (2,4,6,8) {
        $cr->move_to(0,1/10*$i);
        $cr->line_to(1,1/10*$i);
    }
    $cr->stroke;
    $cr->set_source_rgba(@helplinecol2);
    foreach my $i (1,3,5,7,9) {
        $cr->move_to(0,1/10*$i);
        $cr->line_to(1,1/10*$i);
    }
    $cr->stroke;
    $cr->set_line_width($dx*4);
    $cr->set_source_rgba(@helplinecol1);
    foreach my $i (2.5,7.5) {
        $cr->move_to(1/10*$i, 0);
        $cr->line_to(1/10*$i, 1);
    }
    $cr->stroke;

    #draw ticks
    $cr->set_line_width($dx*4);
    $cr->set_source_rgba(0, 0, 0, 0.8);
    foreach my $i (2.5,7.5) {
        $cr->move_to(1/10*$i, 0);
        $cr->line_to(1/10*$i, -0.012);
    }
    $cr->stroke;

    $cr->set_antialias('default');

    foreach my $pos (1..100) {
        next unless(exists $sums{i}->{$pos});
        my $tmp0 = (exists $sums{i}->{$pos}->{0} ? $sums{i}->{$pos}->{0} : 0) / $maxsums{i};
        my $tmp1 = (exists $sums{i}->{$pos}->{1} ? $sums{i}->{$pos}->{1} : 0) / $maxsums{i};
        if($tmp0) {
            $cr->set_source_rgba(@barcol0);
            $cr->rectangle(0, 1-$pos/100-0.004, $tmp0, 0.008);
            $cr->fill;
        }
        if($tmp1) {
            $cr->set_source_rgba(@barcol1);
            $cr->rectangle(0+$tmp0+($tmp0 ? 0.003 : 0), 1-$pos/100-0.004, $tmp1-($tmp0 ? 0.003 : 0), 0.008);
            $cr->fill;
        }
    }

    $cr->restore;

    $cr->save;

    $cr->translate($left+$offset, $offset+10);
    $cr->scale(1,1);
    $cr->set_source_rgba(0, 0, 0, 1);
    $cr->set_font_size(12);
    $font_extents = $cr->font_extents;
    $fontheight = $font_extents->{height};
    $extents = $cr->text_extents('Row Sums of #Hits');
    $cr->move_to(50*$size-$extents->{width}/2, 0-$fontheight/2);
    $cr->show_text('Row Sums of #Hits');

    $cr->set_font_size(10);
    $font_extents = $cr->font_extents;
    $fontheight = $font_extents->{height};
    foreach my $i (2.5,7.5) {
        $extents = $cr->text_extents(&addCommas(int($i/10*$maxsums{c})));
        $cr->move_to(-10-$extents->{width}, ($top-15)*(10-$i)/10+$fontheight/4-1);
        $cr->show_text(&addCommas(int($i/10*$maxsums{c})));
    }

    $cr->translate(101*$size+$top-15, $top-10);
    $cr->rotate($PI * 1 / 2);
    foreach my $i (2.5,7.5) {
        $extents = $cr->text_extents(&addCommas(int($i/10*$maxsums{i})));
        $cr->move_to(-10-$extents->{width}, ($top-15)*(10-$i)/10+$fontheight/4-1);
        $cr->show_text(&addCommas(int($i/10*$maxsums{i})));
    }
    $cr->set_font_size(12);
    $font_extents = $cr->font_extents;
    $fontheight = $font_extents->{height};
    $extents = $cr->text_extents('Column Sums of #Hits');
    $cr->move_to(2+50*$size-$extents->{width}/2,0-$fontheight/2);
    $cr->show_text('Column Sums of #Hits');

    $cr->restore;

    #legend
    $cr->translate($left+$offset+70*$size, $offset+$top+70*$size);
    my $value;
    my $height = $size*2+3;
    $cr->rectangle(-5, -20, $height*$size+30, $height*$size+30);
    $cr->set_source_rgba(0.98, 0.98, 0.98, 1);
    $cr->fill;
    $cr->set_source_rgba(0, 0, 0, 0.8);
    $cr->set_font_size(14);
    $cr->move_to(10-$size,0-3);
    $cr->show_text('Legend');
    $cr->set_font_size(10);
    $font_extents = $cr->font_extents;
    $fontheight = $font_extents->{height};
    $fontdescent = $font_extents->{descent};
    foreach my $i (1..$size) {
        $cr->move_to(10+$height+2,$i*$height+$fontheight/2-$fontdescent);
        $value = $subvals->[$size-$i];
        $cr->show_text(($value > 1 ? ($i == $size ? '    ' : '< ') : '').($value ? &addCommas($value) : ''));
    }
    $cr->set_source_rgba(@dotcol);
    foreach my $i (1..$size) {
        $cr->arc(10,$i*$height, ($size-$i+1), 0, 2*$PI);
        $cr->fill;
    }

    #write image
    $cr->show_page;
    $surface->write_to_png($file);
}

sub calcSubVals {
    my $max = shift;
    if($max <= 1) { #till 10
        return [0,0,0,0,1];
    } elsif(&log10($max) <= 1) { #till 10
        return [1,2,5,8,10];
    } elsif(&log10($max) <= 2) { #till 100
        return [1,10,20,50,100];
    } elsif($max <= 500) { #till 500
        return [1,10,100,300,500];
    } elsif(&log10($max) <= 3) { #till 1,000
        return [1,100,200,500,1000];
    } elsif(&log10($max) <= 4) { #till 10,000
        return [1,100,1000,5000,10000];
    } elsif(&log10($max) <= 5) { #till 100,000
        return [1,100,1000,10000,100000];
    } elsif(&log10($max) <= 6) { #till 1,000,000
        return [1,100,5000,100000,1000000];
    } elsif(&log10($max) <= 7) { #till 10,000,000
        return [1,1000,50000,1000000,10000000];
    } elsif(&log10($max) <= 8) { #till 100,000,000
        return [1,1000,100000,10000000,100000000];
    } elsif(&log10($max) <= 9) { #till 1,000,000,000
        return [1,10000,1000000,100000000,1000000000];
    }
}

sub log10 {
    my $n = shift;
    return log($n)/log(10);
}

sub getSubVal {
    my ($subvals,$val) = @_;
    return 0 if($val == 0);
    my $count = 1;
    foreach(@$subvals) {
        if($val <= $_) {
            return $count;
        }
        $count++;
    }
}

sub addCommas {
    my $num = shift;
    return $num if($num < 1000);
    $num = scalar reverse $num;
    $num =~ s/(\d{3})/$1\,/g;
    $num =~ s/\,$//;
    $num = scalar reverse $num;
    return $num;
}
